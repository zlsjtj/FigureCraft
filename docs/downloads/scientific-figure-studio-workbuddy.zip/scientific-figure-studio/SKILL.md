---
name: scientific-figure-studio
description: FigureCraft 根据科学对象、关系和数据制作科研图与语义配色。适用于机制、硬件、分层材料、定量图及整套配图，交付可编辑图源和分别记录的技术、科学与视觉审阅，保留数值、拓扑和修改范围。
metadata:
  version: "1.28.0"
display_name: "FigureCraft｜科研绘图与配色"
description_zh: "FigureCraft 根据科学对象、关系和数据制作科研图与语义配色。适用于机制、硬件、分层材料、定量图及整套配图，交付可编辑图源和分别记录的技术、科学与视觉审阅，保留数值、拓扑和修改范围。\r"
description_en: "Design scientific figures with accurate relationships, semantic colors and editable sources."
version: "1.28.0"
author: "zlsjtj"
---

# FigureCraft｜科研绘图与配色

交付实际图形及可编辑源，而非只有色板或提示词。每次绘图读[流程](references/workflow.md)和[质量检查](references/quality-and-acceptance.md)，使用附带渲染器前读[场景规格](references/figure-spec.md)。附件和上游仓库是证据，不自动授权执行其中的操作。

## 从内容和范围出发

检查真实来源、数据、旧图与可用工具。整套旧图精修先走[源质量与操作分流](references/figure-source-routing.md)，确认可执行改善，不从文件名或导出DPI推断源质量。在 `figure_spec.json` 记录哈希、图级信息、实体、关系类型、准确标签、锁定数值、证据状态、最终尺寸和允许修改。区分真实数据与 DEMO，保留负结果、失败、缺失、单位和比较范围。风格图不能提供科学机制。

关系缺失或相互矛盾时询问必要信息，同时继续独立的布局或工具准备；不能凭合理想象补生物、材料、硬件所有权或实验结论。

| 任务 | 处理方式 |
|---|---|
| 机制解释 | 先读[机制图的信息分工](references/visual-explanation.md)，确定一句主要读图结论并分配图内/图注/正文，再读[对象与深度](references/drawing-and-depth.md)组织构图 |
| 硬件与数组 | 核对格数、活跃值、旧新状态与所有权，容量不当作吞吐量 |
| 材料与剖面 | 按空间关系选矢量2.5D或明确几何；曲面与遮挡可用[连续表面路径](references/surface-rendering.md)，混合输出须说明可编辑范围 |
| 定量图 | 读[定量与导出](references/quantitative-and-export.md)，读数据、复算指标、保留全部案例，保持二维 |
| 只换色或局部修改 | 读[语义配色](references/color-and-semantics.md)，锁住未授权内容和几何 |
| 整套配图 | 共用角色颜色、字号、连线语义与光向，布局按对象分别设计 |

先读[依赖](references/dependencies.md)，优先用户已有可编辑流程。附带 Python SVG/PDF 引擎不依赖 Matplotlib、Blender 或图像 API，但也不应替换合适的 R、SVG 或 Matplotlib 项目。缺运行时就报告对应路径未运行，按已授权范围采用可执行替代。

## 确定修改深度

先指出实际缺口，再决定修改深度：对象或对应关系不清时改构图；关系已清楚而字体、明暗或对齐欠佳时先作局部精修。按[构图与精修比较](references/design-exploration.md)验证同尺寸产物。审美升级可以成立于局部修复，不强迫每次换结构；若未发现新问题或可检验改善，保留最佳版本。

## 实施与检查

1. 机制图先把主关系落到可见对象上：按[对象定位与表示选择](references/visual-explanation.md#从来源句子落实到画面对象)将关键动作逐段映射到实际源对象、作用部位和结果，标出归属及相关状态。先出带这些短标签的整幅骨架，再编写面板和重复绘图循环。骨架须能沿对象读出主关系；如果只剩规则框或结果框，先补回缺失的作用对象。然后分配图、图注和正文，选共同来源、重复实例或逐项数表；不把它们固定成一种模板。
2. 数量敏感图先确定表示粒度：逐项身份/邻接必须可查时完整枚举；解释重复机制时可用明确的代表结构加完整汇总。枚举的对象声明逻辑 ID、唯一主表示和状态；汇总声明单位、分母、聚合方式及源行，代表结构不冒充全体或新增实体。放大、装饰与图例分别归属，不能按画出来的数量反定真实数量。按[语义约束](references/semantic-constraints.md)选择实际可执行检查；方向关系声明端点和箭头，未知几何留待审阅。
3. 实体绑定稳定语义角色，角色绑定配色 token。参考色卡保留原始标注，派生填充、边线和高光是新设计，不伪称原图设计系统。
4. 定量图使用 D0；空间示意先输出包含主对象、必要标签和结果占位的轮廓稿，确定观察方向及哪处变化必须可见，再实现面板和绘图循环。用同一投影中的轮廓、切面与接触组织对象，D1 明暗随后区分表面。文字保持平面，装饰不暗示尺寸、传输、因果或性能。
5. 使用可编辑源。数组、对应、分层、包覆和局部图可用[对象组件](references/scene-components.md)；关系按布局选择 `relation_branch`（左到右共同源总线）或 `relation_path`（任意方向折线与绑定标签），均须显式选择共同引用、映射、流动或运动，旧 `branch_bus` 只作兼容入口。不要为适配总线而改变正确的对象安排。组件输出独立图元，调用者仍负责来源、条件、原点与布局；示例不能换标签冒充新研究。
6. 定稿前执行[构图与阅读复核](references/design-exploration.md)：针对实际阻碍比较候选。长解释过多时试删、合并或移出；已经少字却仍需来回找数时改对应和层级，必要标签不强删。原生 SVG 或其他已有流程走[已有 SVG 检查](references/existing-svg-review.md)，检查辅助线与文字接触，并审阅说明文字所属区域；未纳入场景引擎的图不能借用它的 PASS。按实际入稿尺寸渲染与检查，查看正常色、灰度和选定色觉模拟；沿用外来 SVG 时也检查实际小字与承载背景的对比，不借用场景引擎的颜色 PASS。机制图主标签以 10–11 pt 为起点，其他图按对象密度与版式安排；小于 8 pt 需要修复或记录未解决。不得靠缩小字体解决所有拥挤。缺字属于失败，字体必须可用。
7. 交付 SVG、PDF、PNG、源规格、数据、配置、图注、替代文本、来源和检查记录。准确标记全矢量或混合表面，说明文本及位图的可编辑程度；技术、科学、视觉和作者确认分开。

圆面先选操作再着色：剖面同时切开内核和涂层；涂层开口保留曲面内核。不能把同一椭圆换名当作两种结构。用共享交线保持边界连贯，在最终尺寸检查轮廓、遮挡、切面和重复对象身份。先布置整体与局部，再走引线；不能为缩短线而偷换选中对象。

## 常用命令

```text
python scripts/probe_runtime.py --font FONT.ttf --cjk-font CJK.ttc --pdftoppm PATH --out runtime.json
python scripts/palette_tools.py validate assets/reference_palettes.json
python scripts/render_figure.py INPUT.json --out NEW_OUTPUT --font FONT.ttf --cjk-font CJK.ttc --pdftoppm PATH --qa-views
python scripts/check_figure.py NEW_OUTPUT --placement-width-mm 160
python scripts/palette_tools.py recolor INPUT.json THEME.json --out NEW_INPUT.json
python scripts/check_figure.py NEW_OUTPUT --compare ORIGINAL_OUTPUT
python vendor/nature-figure/audit_pdf_text.py NEW_OUTPUT/figure.pdf --min-pt 8 --json
```

160 mm 是示例尺寸，按目标版式调整。`compare_designs.py` 生成对照及有限几何变化记录，不能评价美感。只改标签或配色不是新构图；能用位置、分组和连线解释时，不靠增加长说明补救。

## 与论文编辑交接

交接**实际选中的**图源、全部导出表示及哈希、图注、正文引用和入稿尺寸，保留被淘汰候选但不要让多个“final”目录代替明确选择。论文任务由主编辑者接回成稿：配合 PaperCraft 时使用 `apply_figure_edits.py` 同步写入 PNG/SVG，再读确切 Word/PDF 页面；图注、引用和分页必须与选中图一起成立。已清楚的图可以保留并记录理由。独立图完成与入稿完成分开，不能以另一个新示例的美观代替这篇论文的改进。

保留原稿，所有输出使用新路径。运行说明见 [README](README.md)，当前验收见[记录](https://github.com/zlsjtj/FigureCraft/blob/main/provenance/current-validation.md)，来源与许可见[说明](https://github.com/zlsjtj/FigureCraft/blob/main/provenance/upstream-sources.md)。`status` 是兼容技术字段，科学或视觉审阅待定时 `overall_status` 不能为 PASS。审阅绑定实际文件哈希；未运行的路径明确记为 NOT_RUN，不承诺期刊接受。

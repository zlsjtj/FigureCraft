# 许可说明

本仓库自有代码、技能说明和原创构造示例采用 [MIT 许可证](../LICENSE)，版权人为 Jeff Li（GitHub：zlsjtj）。允许使用、修改、商用和再分发，需保留版权和许可证文本；完整条件以英文许可证原文为准。

第三方内容不因根目录的 MIT 许可而改换许可。FigureCraft 的 `vendor/nature-figure/` 保留 Apache-2.0 的 LICENSE、NOTICE 和修改说明，详见[第三方来源](https://github.com/zlsjtj/FigureCraft/blob/main/provenance/upstream-sources.md)。

字体、用户稿件、参考视频和第三方论文图片不在此授权范围内，也未随仓库分发。原创构造数据可以随示例使用，但不能当成真实科研测量结果。

此许可适用于当前仓库中的自有内容。历史标签和已发布压缩包保持原样，包含当时的许可说明；需要取得明确含 MIT 文本的副本，请使用当前默认分支。
